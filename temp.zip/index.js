import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import sequelize from './db.js';

// Route Imports
import AccountRoute from './Routes/Account.route.js';
import UserRoutes from './Routes/User.route.js';
import WebsiteRoutes from './Routes/Website.route.js';
import IntroducerRoutes from './Routes/Introducer.route.js';
import BankRoutes from './Routes/Bank.route.js';
import TransactionRoutes from './Routes/Transaction.route.js';
import DeleteAPIRoute from './Routes/DeleteAPI.route.js';
import EditAPIRoute from './Routes/EditAPI.route.js';
import { AuthRoute } from './Routes/Auth.route.js';
import User from './models/user.model.js';
import UserTransactionDetail from './models/userTransactionDetail.model.js';

dotenv.config();
const app = express();
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(express.urlencoded({ extended: true }));
const allowedOrigins = process.env.FRONTEND_URI.split(',');
app.use(cors({ origin: allowedOrigins }));
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Status : OK');
});

User.hasMany(UserTransactionDetail, { foreignKey: 'userId', as: 'transactionDetails' });
UserTransactionDetail.belongsTo(User, { foreignKey: 'userId', as: 'user' });

AccountRoute(app);
BankRoutes(app);
WebsiteRoutes(app);
IntroducerRoutes(app);
UserRoutes(app);
TransactionRoutes(app);
DeleteAPIRoute(app);
EditAPIRoute(app);
AuthRoute(app);

sequelize
  .sync({ alter: true })
  .then(() => {
    console.log('Database & tables created!');
  })
  .catch((err) => {
    console.error('Unable to create tables:', err);
  });

app.listen(process.env.PORT, () => {
  console.log(`App is running on  - http://localhost:${process.env.PORT || 8000}`);
});
