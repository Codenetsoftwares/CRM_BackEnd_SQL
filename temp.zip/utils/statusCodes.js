export const statusCode = {
  success: 200,
  create: 201,
  badRequest: 400,
  notFound: 404,
  internalServerError: 500,
  inActive: 403,
  unauthorize: 401,
  unauthorize: 401,
  exist: 409,
};
